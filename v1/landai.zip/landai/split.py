import numpy as np
import os
import cv2

mask_path = "./masks"

masks=[]
counter = 0

for i in os.listdir(mask_path):
  masks.append(cv2.imread(os.path.join(mask_path,i),1))
  #print(os.path.join(mask_path,i))

masks = np.array(masks)

print(masks.shape)